document.addEventListener("DOMContentLoaded", function () {
    displayCart();
});

function displayCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartElement = document.getElementById("cart");
    let totalPriceElement = document.getElementById("total-price");
    let shippingInfoElement = document.getElementById("shipping-info");

    cartElement.innerHTML = "";
    let total = 0;

    cart.forEach(item => {
        let li = document.createElement("li");
        li.textContent = `${item.name} - ${item.price} kr`;
        cartElement.appendChild(li);
        total += item.price;
    });

    totalPriceElement.textContent = total;

    if (total >= 300) {
        shippingInfoElement.textContent = "✅ Gratis frakt!";
    } else {
        let remaining = 300 - total;
        shippingInfoElement.textContent = `💡 Handla för ${remaining} kr till för att få gratis frakt!`;
    }
}

document.getElementById("orderForm").addEventListener("submit", function (event) {
    event.preventDefault();

    let customerData = {
        first_name: document.getElementById("first_name").value,
        last_name: document.getElementById("last_name").value,
        address1: document.getElementById("address1").value,
        address2: document.getElementById("address2").value,
        phone: document.getElementById("phone").value,
        zip_code: document.getElementById("zip_code").value,
        city: document.getElementById("city").value,
        products: JSON.parse(localStorage.getItem("cart")) || [],
        total: document.getElementById("total-price").textContent
    };

    fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(customerData)
    }).then(res => res.json())
    .then(data => {
        alert("Tack för din beställning! Betala via Swish.");
        localStorage.removeItem("cart");
        window.location.href = "/";
    });
});