document.addEventListener("DOMContentLoaded", function () {
    let loginSection = document.getElementById("login-section");
    let adminSection = document.getElementById("admin-section");
    let loginForm = document.getElementById("loginForm");

    checkAdminStatus();

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();
        let formData = new FormData(event.target);

        fetch("/admin", {
            method: "POST",
            body: formData
        }).then(res => res.json())
        .then(data => {
            if (data.message === "Login successful") {
                sessionStorage.setItem("admin", "true");
                window.location.reload();
            } else {
                alert(data.message);
            }
        });
    });

    function checkAdminStatus() {
        fetch("/admin/status")
            .then(res => res.json())
            .then(data => {
                if (data.admin) {
                    loginSection.style.display = "none";
                    adminSection.style.display = "block";
                    loadProducts();
                }
            });
    }

    document.getElementById("addProductForm").addEventListener("submit", function (event) {
        event.preventDefault();
        let formData = new FormData(event.target);

        fetch("/api/products", {
            method: "POST",
            body: formData
        }).then(res => {
            if (res.redirected) {
                window.location.href = res.url;
            } else {
                return res.json();
            }
        }).then(() => {
            alert("Produkt tillagd!");
            loadProducts();
        });
    });
});

function loadProducts() {
    fetch("/api/products")
        .then(res => res.json())
        .then(products => {
            let productList = document.getElementById("product-list");
            productList.innerHTML = "";
            products.forEach(product => {
                let item = document.createElement("div");
                item.classList.add("product-item");
                let imageTag = product.image ? `<img src="${product.image}" width="50">` : "";
                item.innerHTML = `${imageTag} <span>${product.name} - ${product.price} kr</span>
                                  <button onclick="deleteProduct(${product.id})">❌</button>`;
                productList.appendChild(item);
            });
        });
}

function deleteProduct(id) {
    fetch(`/api/products/${id}`, {
        method: "DELETE"
    }).then(() => {
        alert("Produkt borttagen!");
        loadProducts();
    });
}

function logout() {
    fetch("/admin/logout", {
        method: "POST"
    }).then(() => {
        sessionStorage.removeItem("admin");
        alert("Du har loggat ut.");
        window.location.reload();
    });
}