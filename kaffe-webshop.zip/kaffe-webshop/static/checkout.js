document.addEventListener("DOMContentLoaded", function () {
    displayCart();
});

function displayCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartElement = document.getElementById("cart");
    let totalPriceElement = document.getElementById("total-price");
    let shippingInfoElement = document.getElementById("shipping-info");

    cartElement.innerHTML = "";
    let total = 0;

    cart.forEach(item => {
        let li = document.createElement("li");
        li.textContent = `${item.name} - ${item.price} kr`;
        cartElement.appendChild(li);
        total += item.price;
    });

    totalPriceElement.textContent = total;

    if (total >= 300) {
        shippingInfoElement.textContent = "✅ Gratis frakt!";
    } else {
        let remaining = 300 - total;
        shippingInfoElement.textContent = `💡 Handla för ${remaining} kr till för att få gratis frakt!`;
    }
}

document.getElementById("orderForm").addEventListener("submit", function (event) {
    event.preventDefault();

    let customerName = document.getElementById("customerName").value;
    let address = document.getElementById("address").value;
    let phone = document.getElementById("phone").value;
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let total = cart.reduce((sum, p) => sum + p.price, 0);

    fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customer_name: customerName, address, phone, products: cart, total: total })
    }).then(res => res.json())
    .then(data => {
        alert("Tack för din beställning! ☕");
        localStorage.removeItem("cart");
        window.location.href = "/";
    });
});