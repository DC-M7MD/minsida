document.addEventListener("DOMContentLoaded", function () {
    fetch("/api/products")
        .then(res => res.json())
        .then(products => {
            let productContainer = document.getElementById("products");
            productContainer.innerHTML = "";

            products.forEach(product => {
                let item = document.createElement("div");
                item.classList.add("product-card");

                let imageUrl = product.image ? product.image : "/static/default-coffee.jpg";

                item.innerHTML = `
                    <img src="${imageUrl}" alt="${product.name}" width="200">
                    <h3>${product.name}</h3>
                    <p>${product.price} kr</p>
                    <button onclick="addToCart(${product.id}, '${product.name}', ${product.price})">Lägg i kundvagn</button>
                `;
                productContainer.appendChild(item);
            });
        })
        .catch(err => console.log("Fel vid hämtning av produkter:", err));
});

function addToCart(id, name, price) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push({ id, name, price });
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${name} har lagts till i kundvagnen!`);
}