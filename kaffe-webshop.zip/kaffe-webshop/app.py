from flask import Flask, request, jsonify, render_template, session, redirect, url_for
import sqlite3
import os
import json
from datetime import datetime
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['SESSION_TYPE'] = 'filesystem'

UPLOAD_FOLDER = "static/uploads"
ORDERS_FOLDER = "orders"
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

DB_FILE = "database.db"

# Skapa mappar om de inte finns
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

if not os.path.exists(ORDERS_FOLDER):
    os.makedirs(ORDERS_FOLDER)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Skapa databasen om den inte finns
def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS products (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        price REAL NOT NULL,
                        image TEXT,
                        soldout INTEGER DEFAULT 0
                    )''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS orders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        first_name TEXT NOT NULL,
                        last_name TEXT NOT NULL,
                        address1 TEXT NOT NULL,
                        address2 TEXT,
                        phone TEXT NOT NULL,
                        zip_code TEXT NOT NULL,
                        city TEXT NOT NULL,
                        products TEXT NOT NULL,
                        total REAL NOT NULL,
                        payment_method TEXT NOT NULL
                    )''')
    conn.commit()
    conn.close()

@app.route('/')
def main_page():
    return render_template('main.html')

@app.route('/products')
def home():
    return render_template('index.html')

@app.route('/cart')
def cart_page():
    return render_template('cart.html')

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username == 'admin' and password == 'admin123':
            session['admin'] = True
            return redirect(url_for('admin_panel'))
        else:
            return render_template('admin_login.html', error="Fel användarnamn eller lösenord")

    return render_template('admin_login.html')

@app.route('/admin/panel')
def admin_panel():
    if 'admin' in session:
        return render_template('admin.html')
    return redirect(url_for('admin_login'))

@app.route('/api/products', methods=['GET', 'POST'])
def manage_products():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    if request.method == 'POST':
        if 'admin' in session:
            name = request.form['name']
            price = request.form['price']
            image = None

            if 'image' in request.files:
                file = request.files['image']
                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(filepath)
                    image = f"/static/uploads/{filename}"

            cursor.execute("INSERT INTO products (name, price, image) VALUES (?, ?, ?)", (name, price, image))
            conn.commit()
            conn.close()
            return redirect(url_for('admin_panel'))
        else:
            return jsonify({"message": "Unauthorized"}), 403

    cursor.execute("SELECT * FROM products")
    products = [{"id": row[0], "name": row[1], "price": row[2], "image": row[3], "soldout": row[4]} for row in cursor.fetchall()]
    conn.close()
    return jsonify(products)

@app.route('/api/products/<int:id>', methods=['DELETE'])
def delete_product(id):
    if 'admin' in session:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM products WHERE id=?", (id,))
        conn.commit()
        conn.close()
        return jsonify({"message": "Produkt raderad!"})
    return jsonify({"message": "Unauthorized"}), 403

@app.route('/api/products/<int:id>/soldout', methods=['POST'])
def mark_soldout(id):
    if 'admin' in session:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("UPDATE products SET soldout = 1 WHERE id=?", (id,))
        conn.commit()
        conn.close()
        return jsonify({"message": "Produkt markerad som slut i lager!"})
    return jsonify({"message": "Unauthorized"}), 403

if __name__ == '__main__':
    init_db()
    app.run(debug=True)